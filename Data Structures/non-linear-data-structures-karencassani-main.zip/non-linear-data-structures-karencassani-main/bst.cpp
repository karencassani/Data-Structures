#include <iostream>
#include <queue>
#include <string>
using namespace std;

struct Node{
    int key;
    Node* left;
    Node* right;
    Node(int item){
        key=item;
        left=NULL;
        right=NULL;
    }
};

Node* insert(Node* node,int key) {
    
    if (node==NULL)
        return new Node(key);
    
   
    if (node->key==key)
        return node;
    if (key<node->key)
        node->left=insert(node->left, key);
    else
        node->right=insert(node->right, key);

    return node;
}
Node* findMin(Node* node) {
    Node* current=node;
    while (current && current->left !=nullptr) {
        current =current->left;
    }
    return current;
}
Node* findMax(Node*node) {
    Node* current =node;
    while (current && current->right !=nullptr) {
        current =current->right;
    }
    return current;
}

Node* search(Node* root,int val) {
    if (root ==nullptr || root->key == val)
        return root;
    if (val <root->key)
        return search(root->left,val);
    return search(root->right,val);
}

Node* findSuccessor(Node* root, Node* target) {
    if (target->right != nullptr)
        return findMin(target->right);

    Node* succ =nullptr;
    while (root !=nullptr) {
        if (target->key < root->key) {
            succ =root;
            root =root->left;
        } else if (target->key > root->key) {
            root =root->right;
        } else break;
    }
    return succ;
}

Node* findPredecessor(Node* root, Node* target) {
    if (target->left != nullptr)
        return findMax(target->left);

    Node* pred =nullptr;
    while (root !=nullptr) {
        if (target->key >root->key) {
            pred =root;
            root =root->right;
        } else if (target->key <root->key) {
            root =root->left;
        } else break;
    }
    return pred;
}

Node* deleteNode(Node* root, int key, bool useSuccessor =true) {
    if (root ==nullptr)
        return root;
    if (key < root->key)
        root->left =deleteNode(root->left,key,useSuccessor);
    else if (key > root->key)
        root->right =deleteNode(root->right,key,useSuccessor);
    else {
        if (root->left ==nullptr) {
            Node* temp =root->right;
            delete root;
            return temp;
        }
        else if (root->right ==nullptr) {
            Node* temp =root->left;
            delete root;
            return temp;
        }

        if (useSuccessor) {
            Node* temp =findMin(root->right);
            root->key =temp->key;
            root->right =deleteNode(root->right, temp->key, useSuccessor);
        } else {
            Node* temp =findMax(root->left);
            root->key =temp->key;
            root->left =deleteNode(root->left,temp->key,useSuccessor);
        }
    }
    return root;
}
void inorder(Node*root){
    if (root != nullptr){
        inorder(root->left);
        cout << root->key << " ";
        inorder(root->right);
    }
}

void preorder(Node* root){
    if (root != nullptr){
        cout << root->key << " ";
        preorder(root->left);
        preorder(root->right);
    }
}

void postorder(Node* root){
    if (root != nullptr){
        postorder(root->left);
        postorder(root->right);
        cout << root->key << " ";
    }
}

void levelorder(Node* root) {
    if (root == nullptr)
        return;

    queue<Node*>q;
    q.push(root);
    int level = 0;

    while (!q.empty()) {
        int size = q.size();
        level++;
        cout << "level " <<level << ": ";
        for (int i = 0; i < size; i++) {
            Node* current = q.front();
            q.pop();
            cout << current->key << " ";
            if (current->left)
                q.push(current->left);
            if (current->right)
                q.push(current->right);
        }
        cout << endl;
    }
    cout << "Total of levels:" <<level << endl;
}

int main() {
 
    Node* root =new Node(20);
    root =insert(root, 15);
    root =insert(root, 10);
    root =insert(root, 12);
    root =insert(root, 8);
    root =insert(root, 6);
    root =insert(root, 4);

    cout <<"Inorder before delete:\n";
    cout <<"Recorrido inorden: ";
    inorder(root);
    cout <<endl;

    cout <<endl;

    root =deleteNode(root, 15, true);
    cout <<"Inorder after deelte using successor:\n";
    inorder(root);
    cout << endl;

    Node* node40 =search(root, 8);
    Node* succ =findSuccessor(root, node40);
    Node* pred =findPredecessor(root, node40);
    cout << "\nsuccessor of 8: " << (succ ? to_string(succ->key) : "none") << endl;
    cout << "Predecessor of 8: " << (pred ? to_string(pred->key) : "none") << endl;

    cout <<"\nTree traversals:\n";
    cout <<"Preorder: ";
    preorder(root);
    cout <<"\nInorder: ";
    inorder(root);
    cout <<"\nPostorder: ";
    postorder(root);
    cout <<"\nLevelorder:\n";
    levelorder(root);

    return 0;
}