[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/-1HAIb3s)
# Sorting Algorithms Analysis

On this coding excersice you will be analyzing 8 common sorting algorithms. Make sure that you document you conclusions in the [Conclusions](#conclusions) section.

Follow instructions from the `Let's code` section at:
https://talks.obedmr.com/content/data-structures/sorting/sorting.html

Include your profile code that you implemented at [ds-profiler](https://github.com/CodersSquad/ds-profiler).

Here the list of sorting algorithms that must be implemented in the [sorting.cpp](./sorting.cpp) file. Don't modify the functions definition.

- Bubble Sort
- Selection Sort
- Insertion Sort
- Merge Sort
- Quick Sort
- Shell Sort
- Heap Sort
- Bucket Sort

## How your program will be tested

**Manual Testing** (please follow the given output format)

Below some examples of executions:

```
./main --algorithm bubble-sort
./main --algorithm bubble-sort 
./main --algorithm selection-sort 
./main --algorithm merge-sort 
./main --algorithm quick-sort 
./main --algorithm shell-sort 
./main --algorithm heap-sort 
./main --algorithm bucket-sort 
```

**With Automation (this is how the professor will test)**

```
make test
```

## Expected Output (of the profiler)

Alongside the `profiler` output, the sorting algorithm should be displayed. Below an example.

```
========================================
| My Profiler       |  program_name    |
|-------------------|------------------|
| Sorting Algorithm | <algorithm_name> |
| Execution Time    | 125 nanoseconds  |
| Memory Usage      | 1 MB             |
========================================
```

## Conclusions

_YOUR CONCLUSIONS MUST BE HERE_

After executing the eight sorting algorithms, it was clear that some were much faster than other, I did a small test of only 5000 elements per sorting algorithm, Insertion Sort was one of the slow alogirthms but between those it was the best, while Bubble Sort was the worst. This matches with what I expected, because bubble sort does many steps and comparisons which makes it take longer to run. The sorting algorithm that was the fastest was the Bucket Sort, and then the Quick Sort. Then it was the Merge Sort, the Shell sort and the Heap sort, these all worked very well. 
The Bubble sort took 31568117 ns, 
the selection sort; 8898128 ns,
the insertion sort; 4021961 ns,
the merge sort; 10008684 ns
the quick sort; 2980599 ns
the shell sort; 5316915 ns
the heap-sort; 5589730 ns
the bucket sort; 1979948 ns

The memory usage between all the algorithms was basically the same or between the same range, they all used between 1-2 MB. For small lists I belive that the best one to use is the Insertion Sort, and for large lists it could be the Bucket Sort since it is the fastest to run. It is really important to choose which algorithm you are going to use depending on the case, since it can make a big difference on how long your program takes to execute. In this case you could see a differentce but it was only with 5000 elements so in other cases of 50,000 elements or more there is a huge difference and is very important the sorting algorithm you use. 


## Grading Policy
| Rubric                 | Points |
|------------------------|--------|
| Sorting Algorithms (8) | 50     |
| Conclusions            | 50     |
| Total                  | 100    |
