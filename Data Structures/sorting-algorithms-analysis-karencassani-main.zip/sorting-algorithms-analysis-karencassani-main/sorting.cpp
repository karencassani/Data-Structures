#include <iostream>
#include "sorting.h"
#include <algorithm>
#include <cmath>

//this one is for the bubble sort 
//this one compares adjacent elements swaps them until sorted
template <typename T>
void bubbleSort(std::vector<T>& vec) {
    for (size_t n = vec.size(); n>1; --n) {
        for (size_t i=0; i < n-1; ++i) {
            if (vec[i] > vec[i+1])
                std::swap(vec[i],vec[i+1]);
        }
    }
}

//this one is for the selection sort

//this one selects the smallest element and puts it in the right place
template <typename T>
void selectionSort(std::vector<T>& vec) {
    for (size_t i = 0; i < vec.size(); ++i) {
        size_t minPos = i;
        for (size_t j = i + 1; j < vec.size(); ++j)
            if (vec[j] < vec[minPos]) minPos = j;
        if (minPos != i) std::swap(vec[i], vec[minPos]);
    }
}

//this one is for the insertionsort it builds the array by inserting element by element 
template <typename T>
void insertionSort(std::vector<T>& vec) {
    for (size_t i = 1; i < vec.size(); ++i) {
        T key = vec[i];
        size_t j = i;
        while (j > 0 && vec[j - 1] > key) {
            vec[j] = vec[j - 1];
            --j;
        }
        vec[j] = key;
    }
}

//this one is for the merge section, it splits the array and sorts various time and then merges them.
template <typename T>
static void mergeSection(std::vector<T>& vec, size_t l, size_t m, size_t r) {
    std::vector<T> temp;
    temp.reserve(r-l+1);
    size_t i=l, j=m+1;
    while (i<=m && j<=r) {
        if (vec[i]<=vec[j]) temp.push_back(vec[i++]);
        else temp.push_back(vec[j++]);
    }
    while (i <= m) temp.push_back(vec[i++]);
    while (j <= r) temp.push_back(vec[j++]);
    for (size_t k = 0; k<temp.size(); ++k) vec[l+k] = temp[k];
}
template <typename T>
static void mergeRec(std::vector<T>& vec, size_t l, size_t r) {
    if (l>=r) return;
    size_t m=l+(r-l) / 2;
    mergeRec(vec,l, m);
    mergeRec(vec,m+1,r);
    if (vec[m] <= vec[m+1]) return;
    mergeSection(vec,l,m,r);
}
template <typename T>
void mergeSort(std::vector<T>& vec) {
    if (!vec.empty()) mergeRec(vec, 0, vec.size() -1);
}

//this one is for the do partition
template <typename T>
static size_t doPartition(std::vector<T>& vec, size_t l, size_t r) {
    T pivot = vec[r];
    size_t i = l;
    for (size_t j = l; j<r; ++j) {
        if (vec[j] <= pivot) { std::swap(vec[i], vec[j]); ++i; }
    }
    std::swap(vec[i], vec[r]);
    return i;
}
template <typename T>
static void quickRec(std::vector<T>& vec, size_t l, size_t r) {
    if (l>=r) return;
    size_t p = doPartition(vec,l,r);
    if (p>0) quickRec(vec,l,p-1);
    quickRec(vec, p + 1, r);
}
template <typename T>
void quickSort(std::vector<T>& vec) {
    if (!vec.empty()) quickRec(vec,0, vec.size() -1);
}

//this one is for the shell short,it compartes the elements by gaps.
template <typename T>
void shellSort(std::vector<T>& vec) {
    for (size_t gap = vec.size()/2; gap>0; gap/=2) {
        for (size_t i = gap; i < vec.size(); ++i) {
            T tmp = vec[i];
            size_t j = i;
            while (j >= gap && vec[j-gap]>tmp) {
                vec[j] = vec[j-gap];
                j-=gap;
            }
            vec[j]=tmp;
        }
        if (gap==1) break;
    }
}

//this one is for the head sorter, it analyzes and extract the biggest element.
template <typename T>
static void heapifyVec(std::vector<T>& vec,size_t n,size_t i) {
    size_t largest = i;
    size_t l =2*i+1, r=2*i+2;
    if (l < n && vec[l] > vec[largest]) largest=l;
    if (r < n && vec[r] > vec[largest]) largest=r;
    if (largest != i) {
        std::swap(vec[i], vec[largest]);
        heapifyVec(vec, n, largest);
    }
}
template <typename T>
void heapSort(std::vector<T>& vec) {
    size_t n=vec.size();
    if (n==0) return;
    for (int i = static_cast<int>(n / 2)-1; i >= 0; --i) heapifyVec(vec,n,i);
    for (size_t i=n-1; i>0; --i) {
        std::swap(vec[0], vec[i]);
        heapifyVec(vec, i, 0);
    }
}

//this one is for the bucket sort , it distributes them into buckets and then it sorts the bucket and merges it. 
template <typename T>
void bucketSort(std::vector<T>& vec) {
    if (vec.empty()) return;

    T mn = *std::min_element(vec.begin(), vec.end());
    T mx = *std::max_element(vec.begin(), vec.end());

    T shift=0;
    if (mn<0) {
        shift=-mn;
        for (auto& v:vec) v += shift;
        mx += shift;
    }

    size_t bucketCount=std::max<size_t>(1, static_cast<size_t>(std::sqrt(vec.size())));
    size_t range=static_cast<size_t>(mx) + 1;
    size_t bucketSize=std::max<size_t>(1, range/bucketCount +(range % bucketCount != 0));

    std::vector<std::vector<T>> buckets(bucketCount);
    for (T v : vec) {
        size_t idx = std::min(bucketCount-1, static_cast<size_t>(v) /bucketSize);
        buckets[idx].push_back(v);
    }

    vec.clear();
    for (auto& b : buckets) {
        std::sort(b.begin(), b.end());
        vec.insert(vec.end(), b.begin(), b.end());
    }

    if (shift) {
        for (auto& v : vec) v -= shift;
    }
}
//we used this to force the compiler to work, it created the versions of these function for vectors with int, in order to be used by the main.cpp without creatin an error. 

template void bubbleSort<int>(std::vector<int>&);
template void selectionSort<int>(std::vector<int>&);
template void insertionSort<int>(std::vector<int>&);
template void mergeSort<int>(std::vector<int>&);
template void quickSort<int>(std::vector<int>&);
template void shellSort<int>(std::vector<int>&);
template void heapSort<int>(std::vector<int>&);
template void bucketSort<int>(std::vector<int>&);

