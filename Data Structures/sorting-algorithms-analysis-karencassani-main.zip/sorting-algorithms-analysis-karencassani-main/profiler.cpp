#include "profiler.h"
#include <chrono>
#include <iostream>
#include <iomanip>
#include <string>
#include <sys/resource.h>
#include <mach/mach.h>

static std::chrono::high_resolution_clock::time_point startMoment; //here is where I save the the initial time and name of the algorith, 
static std::string currentAlgo="<none>";

void setSorterName(const std::string& name){currentAlgo = name;} //Here it register the algorithm, that is being used 

void startProfiling(){ //IT starts the time and shows the profileing has started. 
    startMoment=std::chrono::high_resolution_clock::now();
    std::cout<<" Profiling started.\n";
}

static long long getMemUsageMB(){ //here it will calculate the memory usage by the program in Megabytes.
    struct task_basic_info t_info;
    mach_msg_type_number_t t_info_count=TASK_BASIC_INFO_COUNT;
    if (task_info(mach_task_self(),TASK_BASIC_INFO,(task_info_t)&t_info, &t_info_count)==KERN_SUCCESS) {
        return static_cast<long long>((t_info.resident_size +(1 << 20) - 1) / (1 << 20));
    }
    return -1;
}

void stopProfiling(){ //stops the timer,calculates the duration and memory, and shows the table with the results. 
    auto finish=std::chrono::high_resolution_clock::now();
    auto duration=std::chrono::duration_cast<std::chrono::nanoseconds>(finish - startMoment).count();
    long long memMB=getMemUsageMB();

    std::cout<<"    Profiling finished.\n";
    std::cout<<"===========================================\n";
    std::cout<<"| My Profiler          |  program_name      |\n";
    std::cout<<"|----------------------|---------------------|\n";

    auto printRow=[](const std::string& left,const std::string& right) {
        std::cout <<"|"<< std::left << std::setw(18) << left
                  <<"|"<< std::left << std::setw(16) << right << "|\n";
    };
//It prints thename of the algorithm, the execution time and the memory used. 
    printRow("Sorting Algorithm. ",currentAlgo);
    printRow("Execution Time. ",std::to_string(duration)+ " ns");
    printRow("Memory Usage. ",std::to_string(memMB)+ " MB");
    std::cout << "========================================\n";
}
