#ifndef PROFILER_H
#define PROFILER_H

#include <string>

void setSorterName( const std::string& name ); //This one saves the name of the algorithm selected. 
void startProfiling(); //Starts the timer and prepares for the analysis
void stopProfiling(); //stops the timer and measures the memory 

#endif // PROFILER_H
