#include "profiler.h"
#include "sorting.h"
#include <iostream>
#include <vector>
#include <random>
#include <string>

extern void setSorterName ( const std::string&);

int randomIntGen(int low,int high) { //This functions generates random numbers in the given range
    static std::mt19937 engine{ std::random_device {}()};
    std::uniform_int_distribution<int> distrib (low,high);
    return distrib(engine);
}

int main(int argc, char** argv ) {
    std::vector<int> data;
    int N=10000000;                  //This is the default data of the data set. 
    std::string chosen = "quick-sort";  //It is the default algorith, 
//It checks the program arguments and allows the use to change zie and algorith, 
    if (argc > 2 && std::string( argv[1]) == "--size") {
        N=std::stoi( argv[2]);          
        if (argc>3) chosen=argv[3];  
    } else if (argc>1) {
        chosen =argv[1];                
    }

    //It fills the vector with random numbers
    for (int i = 0; i < N; i++)
        data.push_back(randomIntGen(0, 1000000));

    setSorterName(chosen);

    std::cout << "Running the program\n";
    startProfiling();
//It selects one of the sorting and runs it 
    if (chosen == "bubble-sort") bubbleSort(data);
    else if (chosen == "selection-sort") selectionSort(data);
    else if (chosen == "insertion-sort") insertionSort(data);
    else if (chosen == "merge-sort") mergeSort(data);
    else if (chosen == "quick-sort") quickSort(data);
    else if (chosen == "shell-sort") shellSort(data);
    else if (chosen == "heap-sort") heapSort(data);
    else if (chosen == "bucket-sort") bucketSort(data);
    else {
        std::cerr << "⚠ Unknown algorithm: " << chosen << "\n";
        return 1;
    }
//It stops profiling and shows the results.
    stopProfiling();
    return 0;
}
