#include <iostream>   //It is required for input/output operations 
#include <cstdlib>    //It is required for atoi, converts string to integer 
#include <chrono>    //this will be used to measure the execution elapsed 

int iterativeSum(int n) {//Iterative sum, it goes from 1 to n and it adds it. 
    int sum = 0;
    for (int i = 1; i <= n; i++) sum += i;
    return sum;//It returns the total sum 
}
int recursiveSum(int n) {//Recursive sum, this one sums n+ sum of n-1 
    if (n == 0) return 0 ;
    return n + recursiveSum(n - 1);
}
int directSum(int n) {// it sums directly 
    return n * (n + 1) / 2; //This uses a formula 
}
template<typename function> //this represents a function 
void measuresums(function f, int n, const std::string& label) {
    auto start = std::chrono::high_resolution_clock::now(); // it starts counting
    int result = f(n);//gives us the result 
    auto end = std::chrono::high_resolution_clock::now();//end of elapsed 
    std::chrono::duration<double> elapsed = end - start;//calculates the elapsed 

    std::cout << "# " << label << "with n= " << n << "\n"
              << "  -Result:" << result << "\n"
              << "  -Execution time: " << elapsed.count() << " seconds\n";
}

int main(int argc, char *argv[]) {
    if (argc != 2) {//this verifies that the arugment is valid 
        std::cerr << "Usage: " << argv[0] << " <integer>\n";
        return 1;//It indicates an error 
    }

    int n = std::atoi(argv[1]);
    measuresums(iterativeSum, n, "Iterative Sum");
    measuresums(recursiveSum, n, "Recursive Sum");
    measuresums(directSum, n, "Direct Sum");

    return 0;
}
