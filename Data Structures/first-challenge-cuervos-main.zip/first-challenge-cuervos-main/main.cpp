#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <iomanip>

// función para calcular la suma ASCII 
uint32_t sumaAscii(const std::string &cadena) {
    uint32_t suma = 0;
    for (unsigned char c : cadena) {
        suma += static_cast<uint32_t>(c);
    }
    return suma;
}

int main() {
    std::ifstream archivoEntrada("data.txt", std::ios::binary);
    std::ofstream archivoSalida("suma_lineas.txt");

    if (!archivoEntrada.is_open()) {
        std::cerr << "No se pudo abrir data.txt" << std::endl;
        return 1;
    }

    if (!archivoSalida.is_open()) {
        std::cerr << "No se pudo crear suma_lineas.txt" << std::endl;
        return 1;
    }

    constexpr size_t TAM_LINEA = 256;
    std::string linea(TAM_LINEA, '\0');
    size_t contador = 0;

    while (archivoEntrada.read(&linea[0], TAM_LINEA)) {
        uint32_t valor = sumaAscii(linea);
        archivoSalida << valor << '\t' << linea << '\n';
        ++contador;
    }

    archivoEntrada.close();
    archivoSalida.close();

    std::cout << "Se procesaron " << contador << " líneas de 256 caracteres.\n";
    return 0;
}
