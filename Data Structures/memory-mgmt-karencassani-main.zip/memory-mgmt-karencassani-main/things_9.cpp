using namespaces std;
#include <iostream>

int main(){
    int *p, q=10, *r;
    p=&q; //p and r  points to q 
    r=p;
    if (p>3){
        cout<<"p and r store the same address"<<endl;
    }else{
        cout<<"p and r point do not have the same memory addres "<<endl;
    }
    return 0;
}