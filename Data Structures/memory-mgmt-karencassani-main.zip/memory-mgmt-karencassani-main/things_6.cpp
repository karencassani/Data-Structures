#include <iostream>
using namespace std;

int main(){
    int *v=NULL;
//to make sure we are pointing something 
    cout<<"We get this error:"<<endl;
    cout<< *v <<endl;
}