#include <iostream>
using namespace std;

int main() {
    int *p;
    delete p;
    return 0;
}

