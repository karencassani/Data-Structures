#include <iostream>
using namespace std;

int main () {
    int *p=NULL;
    cout<<*p<<endl;
    return 0;
}