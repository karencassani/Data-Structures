#include <iostream>

using namespace std;
int* foo(){
        int a = 700;
        int *b = &a;
        return b;
}
int main(){
    int *ptr = foo();
    cout << *ptr << endl;
    return 0;
}