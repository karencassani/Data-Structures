#include <iostream>

using namespace std;

int main(){
    int* p, *q, *r;
    p = new int(10000);
    q=r=p; //q equals the same value as r and r equals the same value as p

    cout << "p: "<< *p << endl;
    cout << "q: "<< *q << endl;
    cout << "r: "<< *r << endl;
    delete r; 
    cout << "p: "<< *p << endl;
    cout << "q: "<< *q << endl;
    cout << "r: "<< *r << endl;
    return 0;
}