#include <iostream>
using namespace std;
int main(){
    
    int *value=new int(20);
    cout<<"Value:  "<<*value<<endl;//prints 20 
    value=new int(40); //new memory with value 40 
    cout<<"New value: "<<*value<<endl;
    return 0;
}