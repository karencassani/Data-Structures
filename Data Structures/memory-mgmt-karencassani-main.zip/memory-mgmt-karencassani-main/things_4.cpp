#include <iostream>
using namespace std;
int main(){
    int*p;
    int*q=NULL;

    cout<<"The memory value was not initialized :"<<p<<endl;
    cout<<"The NULL memory value: "<<q<<endl; //0


    return 0;
}