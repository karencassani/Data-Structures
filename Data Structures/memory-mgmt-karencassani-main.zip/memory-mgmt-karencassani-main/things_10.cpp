using namespace std;
#include <iostream>

int main(){

    string*a =new string ("my string"); //create stirng in memory 
    int*b = new int(3); //create int in memory 

    cout<<*b *5 <<endl; //this will print 15 
    cout<<a->size()<<endl;

    return 0;
}