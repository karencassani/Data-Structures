using namespace std;
#include <iostream>

int main(){
    int *p, q = 10, *r; //p and r, are pointers q=10
    p=&q; //p and r point to q 
    r=p;
    cout<< p <<endl;//prints address of q
    cout<< r <<endl;//same addres of q
    cout<<* p <<endl;
    cout<<* r <<endl;// prints value at q 10 
    return 0;
}