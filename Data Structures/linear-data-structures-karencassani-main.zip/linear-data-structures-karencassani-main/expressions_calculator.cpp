#include "expressions_calculator.h"
#include <stack>
#include <sstream>
#include <cctype>
#include <cmath>
#include <stdexcept>

using namespace std;
namespace expr_calc { //el codigo se implementa dentro del namespace expr_calc

//dtermina la prioridad de los operadores matematicos
static int prioridad_operator(const string& op) {
    if (op=="^") return 4; //potencia tiene mayor prioridad
    if (op=="*"||op=="/"||op=="%") return 3; //multiplicacion  division y módulo
    if (op=="+"||op=="-") return 2; //suma y resta
    return 0;
}

// Indica si el operador es asociativo a la derecha (solo ^)
static bool evaluate_right(const string& op) {
    return op == "^";
}

// Verifica si el caracter es un operador válido
static bool valid_operator(char c) {
    return c=='+'||c=='-'||c=='*'||c=='/'||c=='^'||c=='%'; 
}

// Convierte la expresion en tokens, manejando el signo menos unario (por ejemplo: -5)
static vector<string>tokenize_user(const string& s) {
    vector<string> tokens;
    size_t i=0;
    while (i<s.size()) {
        if (isspace((unsigned char)s[i])) { ++i; continue; }
        char c = s[i];
        if (isdigit((unsigned char)c) || c=='.') {
            //detecta numeros enteros o decimales
            size_t j=i;
            while (j<s.size() && (isdigit((unsigned char)s[j])||s[j]=='.')) ++j;
            tokens.push_back(s.substr(i,j-i));
            i=j;
        } else if (c=='('||c==')') {
            //parentesis como tokens individuales
            tokens.push_back(string(1,c));
            ++i;
        } else if (valid_operator(c)) {
            //verifica si el menos es unario
            if (c == '-') {
                bool unary = false;
                if (tokens.empty()) unary = true;
                else {
                    string prev = tokens.back();
                    if (prev=="("|| valid_operator(prev[0])) unary = true;
                }
                if (unary) {
                    // Convierte -x en 0-x
                    tokens.push_back("0");
                    tokens.push_back("-");
                    ++i;
                    continue;
                }
            }
            //agrega el operador como token
            tokens.push_back(string(1, c));
            ++i;
        } else {
            //si se encuentra un caracter inválido, lanza excepción
            throw runtime_error(string("Invalid character in expression: '") + c + "'");
        }
    }
    return tokens;
}

//convierte una expresión infija a postfija usando el algoritmo de Shunting-yard
vector<string> convert_postfix(const string& infix) {
    vector<string> output;
    stack<string> st;
    vector<string> tokens = tokenize_user(infix);

    for (const string& tok : tokens) {
        if (tok.empty()) continue;
        //si es número, lo agrega a la salida
        if (isdigit((unsigned char)tok[0]) || (tok.size()>1 && isdigit((unsigned char)tok[1]))) {
            output.push_back(tok);
        } else if (tok == "("){
            st.push(tok);
        } else if (tok == ")"){
            //saca operadores hasta encontrar '('
            while (!st.empty() && st.top()!="(") {
                output.push_back(st.top());
                st.pop();
            }
            if (st.empty()) throw runtime_error("Mismatched parentheses");
            st.pop();
        } else {
            //si es operador, compara precedencia y asocia
            string op1 = tok;
            while (!st.empty()) {
                string op2 = st.top();
                if (op2 == "(") break;
                int p1 = prioridad_operator(op1);
                int p2 = prioridad_operator(op2);
                if ((evaluate_right(op1) && p1<p2) ||
                    (!evaluate_right(op1) && p1<=p2)) {
                    output.push_back(op2);
                    st.pop();
                } else break;
            }
            st.push(op1);
        }
    }

    //saca cualquier operador restante de la pila
    while (!st.empty()) {
        if (st.top()=="("||st.top() == ")")throw runtime_error("Mismatched parentheses");
        output.push_back(st.top());
        st.pop();
    }

    return output;
}

//evalúa una expresión en notación postfija y regresa el resultado
double calculate(const vector<string>& postfix) {
    stack<double> st;
    for (const string& tok : postfix) {
        if (tok.empty()) continue;
        //si es número, lo mete a la pila
        if (isdigit((unsigned char)tok[0])||tok[0]=='.'||(tok.size()>1 && tok[0]=='-' && isdigit((unsigned char)tok[1]))) {
            double val = stod(tok);
            st.push(val);
        } else {
            //si es operador, saca dos operandos y aplica la operación
            if (st.size() < 2) throw runtime_error("Invalid postfix expression");
            double right=st.top(); st.pop();
            double left =st.top(); st.pop();
            double res=0.0;
            if (tok=="+") res = left + right;
            else if (tok=="-") res = left - right;
            else if (tok=="*") res = left * right;
            else if (tok=="/") {
                if (right==0.0) throw runtime_error("Division by zero");
                res = left/right;
            } else if (tok=="^") {
                res = pow(left,right);
            } else if (tok=="%") {
                if (right==0.0) throw runtime_error("Modulo by zero");
                res = fmod(left, right);
            } else throw runtime_error("Unknown operator: " + tok);
            st.push(res);
        }
    }
    if (st.size() != 1) throw runtime_error("Invalid postfix evaluation");
    return st.top();
}

//une los tokens postfijos en una sola cadena sin espacios
string unite_postfix(const vector<string>& postfix) {
    string out;
    for (const string& t:postfix) out+=t;
    return out;
}

} // namespace expr_calc
