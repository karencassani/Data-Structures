#ifndef EXPRESSIONS_CALCULATOR_H
#define EXPRESSIONS_CALCULATOR_H

#include <string>
#include <vector>

namespace expr_calc {

std::vector<std::string> convert_postfix(const std::string& infix);

double calculate(const std::vector<std::string>& postfix);

std::string unite_postfix(const std::vector<std::string>& postfix);

} 

#endif // EXPRESSIONS_CALCULATOR_H
