#pragma once
#include <stdexcept>
namespace linked_list {
template <typename U>
class List {
private:
    struct Entry {
        U payload;
        Entry* prev_link;
        Entry* next_link;
        explicit Entry(const U& datum)
            : payload(datum), prev_link(nullptr), next_link(nullptr) {}
    };
    Entry* first_ = nullptr;
    Entry* last_  = nullptr;
    int length_   = 0;
public:
    List() = default;
    ~List() {
        while (first_) {
            Entry* sweep = first_;
            first_ = first_->next_link;
            delete sweep;
        }
    }
    void push(const U& item) {
        Entry* slot = new Entry(item);
        if (!last_) {
            first_ = last_ = slot;
        } else {
            last_->next_link = slot;
            slot->prev_link  = last_;
            last_ = slot;
        }
        ++length_;
    }
    U pop() {
        if (!last_) throw std::runtime_error("List is empty");
        Entry* slot = last_;
        U out = slot->payload;
        last_ = last_->prev_link;
        if (last_) last_->next_link = nullptr;
        else first_ = nullptr;
        delete slot;
        --length_;
        return out;
    }
    U shift() {
        if (!first_) throw std::runtime_error("List is empty");
        Entry* slot = first_;
        U out = slot->payload;
        first_ = first_->next_link;
        if (first_) first_->prev_link = nullptr;
        else last_ = nullptr;
        delete slot;
        --length_;
        return out;
    }
    void unshift(const U& item) {
        Entry* slot = new Entry(item);
        if (!first_) {
            first_ = last_ = slot;
        } else {
            slot->next_link = first_;
            first_->prev_link = slot;
            first_ = slot;
        }
        ++length_;
    }
    int count() const { return length_; }
    bool erase(const U& target) {
        Entry* walker = first_;
        while (walker) {
            if (walker->payload == target) {
                if (walker->prev_link) walker->prev_link->next_link = walker->next_link;
                else first_ = walker->next_link;
                if (walker->next_link) walker->next_link->prev_link = walker->prev_link;
                else last_ = walker->prev_link;
                delete walker;
                --length_;
                return true;
            }
            walker = walker->next_link;
        }
        return false;
    }
};
}  // namespace linked_list
