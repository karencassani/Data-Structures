#include "search.h"
#include <vector>
#include <string>

template int linearSearch< int > ( const std::vector<int > & , const int &);
template int linearSearch< double > (const std::vector<double > & , const double &);
template int linearSearch<std::string > ( const std::vector < std::string > &, const std::string &);
