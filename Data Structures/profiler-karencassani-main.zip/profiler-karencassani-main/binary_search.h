#ifndef BINARY_SEARCH_H
#define BINARY_SEARCH_H
#include <vector>
#include <string>

template<typename T>
void combinearr(std::vector<T>& arr,int low,int mid,int high);
template<typename T>
void combine_sort(std::vector<T>& arr,int low,int high);
template<typename T>
void sortarrau(std::vector<T>& arr);
template <typename T>
int Iterative(const std::vector<T>& data,const T& target);
template <typename T>
int Recursive(const std::vector<T>& data,const T& target, int low, int high);
template <typename T>
int Recursive(const std::vector<T>& data,const T& target);
#endif
