#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <cctype>
#include "profiler.h"
#include "search.h"        // para linearSearch
#include "binary_search.h" // para iterative y recursive


template<typename T>
bool cargarDatos(const std::string& archivo, std::vector<T>& salida) {
    std::ifstream fin(archivo);
    if (!fin.is_open()) return false;
    T valor;
    while (fin >> valor) salida.push_back(valor);
    return true;
}

template<typename T>
bool ejecutarBusqueda(const std::string& archivo, const std::string& objectivestr, const std::string& algorithm) {
    std::vector<T> coleccion;
    if (!cargarDatos<T>(archivo, coleccion)) {
        std::cerr << "No se pudo abrir " << archivo << "\n";
        return false;
    }

    T objective{};
    if constexpr (std::is_same<T,int>::value) objective = std::stoi(objectivestr);
    else if constexpr (std::is_same<T,double>::value) objective = std::stod(objectivestr);
    else objective = objectivestr;

   
    if (algorithm != "-sequential-search") sortarrau(coleccion);

    int idx = -1;
    if (algorithm == "-sequential-search") idx = linearSearch(coleccion, objective);
    else if (algorithm == "-binary-search") idx = Iterative(coleccion, objective);
    else if (algorithm == "-recursive-binary-search") idx = Recursive(coleccion, objective);

    return idx != -1;
}

int main(int argc, char* argv[]) {
    if (argc < 5) {
        std::cerr << "Use: ./main --input <file> --target <value> [--sequential-search | --binary-search | --recursive-binary-search]\n";
        return 1;
    }

    std::string archivoEntrada, objectivestr, algorithm;
    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--input" && i + 1 < argc) archivoEntrada = argv[++i];
        else if (a == "--target" && i + 1 < argc) objectivestr = argv[++i];
        else if (a == "--sequential-search" || a == "--binary-search" || a == "--recursive-binary-search")
            algorithm = a;
    }

    if (archivoEntrada.empty() || objectivestr.empty() || algorithm.empty()) {
        std::cerr << "Error: revisa --input, --target y tipo de búsqueda\n";
        return 1;
    }

    ProgramLabel(argv[0]);
    starttrack();

    bool found = false;
    if (archivoEntrada.find("integers") != std::string::npos) 
        found = ejecutarBusqueda<int>(archivoEntrada, objectivestr, algorithm);
    else if (archivoEntrada.find("floats") != std::string::npos) 
        found = ejecutarBusqueda<double>(archivoEntrada, objectivestr, algorithm);
    else if (archivoEntrada.find("strings") != std::string::npos) 
        found = ejecutarBusqueda<std::string>(archivoEntrada, objectivestr, algorithm);
    else {
        std::ifstream fin(archivoEntrada);
        if (!fin.is_open()) { std::cerr << "No se puede abrir " << archivoEntrada << "\n"; return 1; }
        std::string primero; fin >> primero; fin.close();
        bool tieneAlpha = false, tieneDot = false;
        for (char c : primero) {
            if (std::isalpha(static_cast< unsigned char > (c))) { tieneAlpha = true ; break; }
            if (c == '.') tieneDot = true;
        }
        if (tieneAlpha) found = ejecutarBusqueda<std::string>(archivoEntrada, objectivestr, algorithm);
        else if (tieneDot) found = ejecutarBusqueda<double>(archivoEntrada, objectivestr, algorithm);
        else found = ejecutarBusqueda<int>(archivoEntrada, objectivestr, algorithm);
    }

    std::string namealgorithm = (algorithm == "--sequential-search") ? "Lineal Search" :
                                   (algorithm == "--binary-search") ? "binary iterative search " : 
                                   "binary recursive search";

    std::string datostype = (archivoEntrada.find("integers") != std::string::npos) ? "Enteros" :
                            (archivoEntrada.find("floats") != std::string::npos) ? "Decimales" :
                            (archivoEntrada.find("strings") != std::string::npos) ? "Cadenas" : "Desconocido";

    std::cout << "Search the algorithm : " << namealgorithm << "\n"
              << "type of file   : " << archivoEntrada << "\n"
              << "Type of data     : " << datostype << "\n"
              << "Value found       : " << objectivestr << "\n"
              << "result             : " << (found ? "found" : "Not found") << "\n";

    endtrack();
    return 0;
}
