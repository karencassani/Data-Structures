#define SEQUENTIAL_SEARCH_H
#ifndef SEQUENTIAL_SEARCH_H
#include <string>
#include <vector>
int linearSearch( const std :: vector<int>& data , int target);
int linearSearch(const std :: vector<double>& data, double target);
int linearSearch(const std :: vector<std::string>& data, const std::string& target);

#endif 
