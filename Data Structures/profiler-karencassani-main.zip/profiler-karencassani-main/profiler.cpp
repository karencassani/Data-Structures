#include "profiler.h"
#include <iostream>
#include <chrono>
#include <string>
#include <fstream>
#include <sstream>

static std::chrono::high_resolution_clock::time_point startTimeTrack;
static std::string programLabel;

void ProgramLabel(const std::string& name) { programLabel=name; }
void starttrack() {startTimeTrack = std::chrono::high_resolution_clock::now(); }

static long getMemoryMB() {
#ifdef _linux_
    std::ifstream f("/proc/self/status");
    std::string line;
    while (std::getline(f, line)) {
        if (line.rfind("VmRSS:", 0) == 0) {
            std::istringstream iss(line);
            std::string key, unit;
            long kb=0;
            if (iss >> key >> kb >> unit) return kb / 1024;
        }
    }
#endif
    return 0;
}

void endtrack() {
    auto endTime=std::chrono::high_resolution_clock::now();
    auto elapsedTime=std::chrono::duration_cast<std::chrono::nanoseconds>(endTime - startTimeTrack).count();
    long memoryUsed=getMemoryMB();

    auto padText=[](const std::string& s,size_t width) {
        return (s.size()>= width)? s.substr(0, width) : s + std::string(width - s.size(), ' ');
    };

    std::cout << "====================================\n"
              << "|" << padText ("Profiler Stats",16)
              << "|" << padText(" " + programLabel +, 17) << "|\n"
              << "|" << std::string(16) << "|" << std :: string(17) << "|\n"
              << "|" << padText("Tiempo Ejecución", 16)
              << "|" << padText(" "+std::to_string(elapsedTime) + " ns ",17) << "|\n"
              << "|" << padText("Uso Memoria", 16)
              << "|" << padText(" "+std::to_string(memoryUsed) + " MB ",17) << "|\n"
              << "====================================\n";
}
