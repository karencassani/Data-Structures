#ifndef PROFILER_H
#define PROFILER_H

#include <string>

void ProgramLabel(const std::string& name);
void starttrack();
void endtrack();

#endif // PROFILER_H
