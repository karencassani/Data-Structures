#include "binary_search.h"
#include <vector>
#include <string>


template<typename T>
void combine(std::vector<T>& coleccion, int start, int medio, int fin) {
    std::vector<T> auxiliar;
    auxiliar.reserve(fin - start + 1);

    int izq = start, der = medio + 1;
    while (izq <= medio && der <= fin) {
        if (coleccion[izq] <= coleccion[der])
            auxiliar.push_back(coleccion[izq++]);
        else
            auxiliar.push_back(coleccion[der++]);
    }

    while (izq <= medio) auxiliar.push_back(coleccion[izq++]);
    while (der <= fin) auxiliar.push_back(coleccion[der++]);

    for (int i = start; i <= fin; ++i) 
        coleccion[i] = auxiliar[i - start];
}

template<typename T>
void orden_recursivo(std::vector<T>& coleccion, int start, int fin) {
    if (start < fin) {
        int medio = start + (fin - start) / 2;
        orden_recursivo(coleccion, start, medio);
        orden_recursivo(coleccion, medio + 1, fin);
        combine(coleccion, start, medio, fin);
    }
}

template<typename T>
void orden(std::vector<T>& coleccion) {
    if (!coleccion.empty()) 
        orden_recursivo(coleccion, 0, static_cast<int>(coleccion.size()) - 1);
}


template<typename T>
int binarioiterativo(const std::vector<T>& list, const T& objective) {
    int start = 0, fin = static_cast<int>(list.size()) - 1;
    while (start <= fin) {
        int medio = start + (fin - start) / 2;
        if (list[medio] == objective) return medio;
        else if (list[medio] < objective) start = medio + 1;
        else fin = medio - 1;
    }
    return -1;
}

template<typename T>
int binariorecursivo(const std::vector<T>& list, const T& objective, int start, int fin) {
    if (start > fin) return -1;
    int medio = start + (fin - start) / 2;
    if (list[medio] == objective) return medio;
    else if (list[medio] < objective) return binariorecursivo(list, objective, medio + 1, fin);
    else return binariorecursivo(list, objective, start, medio - 1);
}

template<typename T>
int binariorecursivo(const std::vector<T>& list, const T& objective) {
    return binariorecursivo(list, objective, 0, static_cast<int>(list.size()) - 1);
}

template void orden<int>(std::vector<int>&);
template void orden<double>(std::vector<double>&);
template void orden<std::string>(std::vector<std::string>&);

template int binarioiterativo<int>(const std :: vector<int>&, const int&);
template int binarioiterativo<double>(const std :: vector<double>&, const double&);
template int binarioiterativo<std::string>(const std :: vector< std:: string>&, const std :: string&);

template int binariorecursivo<int>( const std :: vector<int>&, const int&);
template int binariorecursivo<double>(const std :: vector<double>&, const double&);
template int binariorecursivo<std :: string>( const std :: vector<std :: string>&, const std :: string&);
