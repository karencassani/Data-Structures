#include <iostream>
#include <string>

using namespace std;
int findrecursive ( int num, int d) {
    if (num ==0 ) return 0; //aqui es cuando ya no quedan digito que chcecar
    int digit= num %10 ; //aqui  es para agarrar el ultimo digito 
    if (digit ==d ) return 1 ; //aqui encuentra el ultimo digito 
    return findrecursive ( num /10 , d );  //aqui lo entrega 
}

int find_digit(float n, int d) {
  int dnumber= (int)(n*10000); //aqui lo estamos multiplicando por 10000 por si nos dan un numero con 4 decimales, al multiplicarlo lo convertimos en un entero 
  if (dnumber== 0 && d==0) return 1;//esto es diferente, es para que siga funcionando el codigo cuando el ultimo digito es 0 
  return findrecursive (dnumber, d);
  

  return 0;
}

int main(int argc, char** argv) {

  float number;
  int digit;
  
  if (argc < 3) {
    cout << "You must pass a a float number and the digit to find" << endl;
    cout << "Example: " << argv[0] << " 1.134 3" << endl;
      return -1;
  }

  number = stof(argv[1]);
  digit = stoi(argv[2]);
  
  cout << "Looking for [" << digit << "] digit in: [" << number << "]" << endl;

  if ( find_digit(number, digit) == 1 )
    cout << "Found" << endl;
  else
    cout << "Not Found" << endl;
  return 0;
}